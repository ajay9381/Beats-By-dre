# Changelog

All notable changes to this project will be documented in this file.

## 2025-10-25 - Initial public release
- Added repository scaffold, documentation, and links.
- Prepared folders for quantitative/qualitative exports, presentation, and dashboard assets.
